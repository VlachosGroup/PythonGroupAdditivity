# 2016. Vlachos Group Geun Ho Gu. University of Delaware.


####
#
# setuptools likes to see a name for the package,
# and it's best-practices to have the __version__
# present, too:
#
name = 'pgradd'
__version__ = '1.0.0'
#
####
